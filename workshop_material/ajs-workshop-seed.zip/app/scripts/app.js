"use strict";

// angular.module('myApp', ['ngRoute']);
